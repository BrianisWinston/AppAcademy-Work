class CatsController < ApplicationController
  before_action :logged_in, only: [:show, :edit, :update]
  before_action :find_cat,  only: [:show, :edit, :update]

  def index
    @cats = Cat.all
    render :index
  end

  def show
    render :show
  end

  def new
    @cat = Cat.new
    render :new
  end

  def create
    # cats_params[:user_id] = current_user.id
    @cat = Cat.new(cat_params)
    @cat.owner = current_user
    if @cat.save
      redirect_to cat_url(@cat)
    else
      flash.now[:errors] = @cat.errors.full_messages
      render :new
    end
  end

  def edit
    render :edit
  end

  def update
    if @cat.update_attributes(cat_params)
      redirect_to cat_url(@cat)
    else
      flash.now[:errors] = @cat.errors.full_messages
      render :edit
    end
  end

  private

  def cat_params
    params.require(:cat).permit(:age, :birth_date, :color, :description, :name, :sex, :owner)
  end

  def logged_in
    if !current_user
      redirect_to new_sessions_url
    else
      @current_user_cats = current_user.cats
    end
  end

  def find_cat
    @cat = @current_user_cats.find(params[:id])
  end
end
